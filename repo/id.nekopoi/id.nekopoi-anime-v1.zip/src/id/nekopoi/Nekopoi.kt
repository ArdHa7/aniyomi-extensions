package eu.kanade.tachiyomi.extension.id.nekopoi

import eu.kanade.tachiyomi.source.model.*
import eu.kanade.tachiyomi.source.online.ParsedAnimeHttpSource
import okhttp3.Response
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

class Nekopoi : ParsedAnimeHttpSource() {

    override val name = "Nekopoi"
    override val baseUrl = "https://nekopoi.care"
    override val lang = "id"
    override val supportsLatest = true

    override val client = network.cloudflareClient

    override fun popularAnimeSelector() = "div.eropost"
    override fun popularAnimeRequest(page: Int) =
        GET("$baseUrl/page/$page/", headers)
    override fun popularAnimeFromElement(element: Element) = SAnime.create().apply {
        title = element.selectFirst("h2")?.text() ?: "No title"
        thumbnail_url = element.selectFirst("img")?.absUrl("src")
        setUrlWithoutDomain(element.selectFirst("a")?.attr("href") ?: "")
    }
    override fun popularAnimeNextPageSelector() = "a.next"

    override fun animeDetailsParse(document: Document) = SAnime.create().apply {
        title = document.selectFirst("h1")?.text() ?: "No Title"
        description = document.selectFirst(".entry-content")?.text()
        genre = document.select(".genre a").joinToString { it.text() }
    }

    override fun episodeListSelector() = "div.entry-content a[href*='.mp4']"
    override fun episodeFromElement(element: Element) = SEpisode.create().apply {
        name = element.text()
        setUrlWithoutDomain(element.absUrl("href"))
    }

    override fun videoUrlParse(document: Document): List<Video> {
        return emptyList()
    }
}
