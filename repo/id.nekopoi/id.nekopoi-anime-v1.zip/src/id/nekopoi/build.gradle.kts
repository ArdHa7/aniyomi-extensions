ext {
    extName = "Nekopoi"
    pkgNameSuffix = "id.nekopoi"
    extClass = ".Nekopoi"
    extVersionCode = 1
    nsfw = true
}
